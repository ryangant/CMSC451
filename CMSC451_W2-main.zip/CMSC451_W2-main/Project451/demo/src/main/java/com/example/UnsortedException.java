package com.example;

public class UnsortedException extends Exception {
    public UnsortedException(String msg) { super(msg); }
}
